/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author brysa
 */
/**
 *
 * Functional interface used to demonstrate the lambda expression. The method
 * takes two strings, a username, and password.  *
 *
 *
 */
public interface LoginInterface {

    void setLogin(String username, String password);

}

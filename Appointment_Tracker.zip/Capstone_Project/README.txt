README

Title: Physician's Appointment Tracker -
Purpose: Appointment management through the manipulation of database data

Author: Bryan Sawchyn
Contact: (336)-986-8218, Bsawchy@wgu.edu, V1, 03/26/2021

IDE: Apache NetBeans IDE 12.2 - JDK11 Compatible

Directions: Unzip file BSawchyn_Software_II_PA_Attempt1.zip - Open Dist folder --  run Software_II_Project.jar


